# JsonView

#### 介绍
一个json格式化查看工具

可执行文件在 /JsonView/bin目录

联系方式：邮箱beetle082@163.com，qq:275951533

**源码地址**<br/>
https://gitee.com/beetle082/JsonView <br/>
https://github.com/hao117/JsonView<br/>
![](./img/ui.png)