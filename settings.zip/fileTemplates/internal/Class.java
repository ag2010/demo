#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME};#end
#parse("File Header.java")
/**
  *
  *@ClassName: ${NAME}
  *@Description: TODO
  *@Author: ${USER}
  *@Date: ${DATE}
  *@Version: 1.0
 **/
public class ${NAME} {
}
